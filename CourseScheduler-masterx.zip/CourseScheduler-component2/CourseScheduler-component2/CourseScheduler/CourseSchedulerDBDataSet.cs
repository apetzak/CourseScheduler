﻿namespace CourseScheduler
{
}

namespace CourseScheduler
{
}

namespace CourseScheduler
{
}
namespace CourseScheduler
{


    public partial class CourseSchedulerDBDataSet
    {
    }
}
namespace CourseScheduler {
    
    
    public partial class CourseSchedulerDBDataSet {
    }
}
namespace CourseScheduler {
    
    
    public partial class CourseSchedulerDBDataSet {
    }
}

